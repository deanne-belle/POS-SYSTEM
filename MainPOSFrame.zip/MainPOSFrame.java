import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.*;
import java.util.List;

//Product Classes
abstract class Product {
    private String name;
    private double price;

    public Product(String name, double price) {
        this.name = name;
        this.price = price;
    }
    public String getName() { return name; }
    public double getPrice() { return price; }
}

class DrinkItem extends Product {
    public DrinkItem(String name, double price) { super(name, price); }
}

class FoodItem extends Product {
    public FoodItem(String name, double price) { super(name, price); }
}

//Cart System
class CartItem {
    private Product product;
    private int quantity;

    public CartItem(Product product) {
        this.product = product;
        this.quantity = 1;
    }

    public Product getProduct() { return product; }
    public int getQuantity() { return quantity; }
    public void incrementQuantity() { quantity++; }
    public double getTotalPrice() { return product.getPrice() * quantity; }
}

class Cart {
    private java.util.List<CartItem> items = new ArrayList<>();

    public void addProduct(Product product) {
        for (CartItem item : items) {
            if (item.getProduct().getName().equals(product.getName())) {
                item.incrementQuantity();
                return;
            }
        }
        items.add(new CartItem(product));
    }

    public List<CartItem> getItems() { return items; }

    public double getTotal() {
        return items.stream().mapToDouble(CartItem::getTotalPrice).sum();
    }

    public void clear() { items.clear(); }
}

//Register Display
class RegisterDisplay extends JPanel {
    private JLabel messageLabel;

    public RegisterDisplay() {
        setLayout(new BorderLayout());
        setBackground(Color.BLACK);
        setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY, 3));

        messageLabel = new JLabel("Welcome! Please select an item...", SwingConstants.CENTER);
        messageLabel.setForeground(Color.GREEN);
        messageLabel.setFont(new Font("Consolas", Font.BOLD, 16));
        messageLabel.setOpaque(false);

        add(messageLabel, BorderLayout.CENTER);
    }

    public void showMessage(String message) {
        messageLabel.setText(message);
    }
}

//Product Panel
class ProductPanel extends JPanel {
    public ProductPanel(List<Product> products, Cart cart, Runnable onCartUpdate) {
        setLayout(new GridLayout(0, 3, 10, 10));
        setBorder(new EmptyBorder(10, 10, 10, 10));

        for (Product product : products) {
            JButton button = new JButton("<html><center>" + product.getName() +
                    "<br>₱" + product.getPrice() + "</center></html>");
            button.setFont(new Font("Arial", Font.BOLD, 14));
            button.setBackground(new Color(210, 180, 140));
            button.setFocusPainted(false);

            button.addActionListener(e -> {
                cart.addProduct(product);
                onCartUpdate.run();
            });
            add(button);
        }
    }
}

//Cart Panel
class CartPanel extends JPanel {
    private JTable table;
    private DefaultTableModel model;
    private JLabel totalLabel;

    public CartPanel() {
        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(250, 0));
        setBorder(BorderFactory.createTitledBorder("Cart"));

        model = new DefaultTableModel(new Object[]{"Item", "Qty", "Price"}, 0);
        table = new JTable(model);
        totalLabel = new JLabel("Total: ₱0.00", SwingConstants.CENTER);
        totalLabel.setFont(new Font("Arial", Font.BOLD, 16));

        add(new JScrollPane(table), BorderLayout.CENTER);
        add(totalLabel, BorderLayout.SOUTH);
    }

    public void updateCart(Cart cart) {
        model.setRowCount(0);
        for (CartItem item : cart.getItems()) {
            model.addRow(new Object[]{
                    item.getProduct().getName(),
                    item.getQuantity(),
                    String.format("₱%.2f", item.getTotalPrice())
            });
        }
        totalLabel.setText("Total: ₱" + String.format("%.2f", cart.getTotal()));
    }
}

//Start up panel
class StartPanel extends JPanel {
    public StartPanel(Runnable onStart) {
        setLayout(new BorderLayout());
        setBackground(new Color(20, 20, 20));

        JLabel title = new JLabel("Welcome to Coffee Shop (Name)", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 26));
        title.setForeground(Color.GREEN);

        JLabel msg = new JLabel("Would you like to start ordering?", SwingConstants.CENTER);
        msg.setFont(new Font("Arial", Font.PLAIN, 20));
        msg.setForeground(Color.WHITE);

        //Buttons
        JButton startBtn = new JButton("Start Order");
        JButton exitBtn = new JButton("Exit");

        startBtn.setFont(new Font("Arial", Font.BOLD, 18));
        startBtn.setBackground(new Color(46, 139, 87));
        startBtn.setForeground(Color.WHITE);
        startBtn.setFocusPainted(false);
        startBtn.setPreferredSize(new Dimension(150, 45));

        exitBtn.setFont(new Font("Arial", Font.BOLD, 18));
        exitBtn.setBackground(new Color(178, 34, 34));
        exitBtn.setForeground(Color.WHITE);
        exitBtn.setFocusPainted(false);
        exitBtn.setPreferredSize(new Dimension(150, 45));

        startBtn.addActionListener(e -> onStart.run());
        exitBtn.addActionListener(e -> System.exit(0));

        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(new Color(20, 20, 20));
        bottomPanel.add(startBtn);
        bottomPanel.add(Box.createHorizontalStrut(15));
        bottomPanel.add(exitBtn);

        add(title, BorderLayout.NORTH);
        add(msg, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);
    }
}

//Main POS Frame
public class MainPOSFrame extends JFrame {
    private Cart cart = new Cart();
    private CartPanel cartPanel;
    private RegisterDisplay display;
    private JPanel mainPanel;

    public MainPOSFrame() {
        setTitle("Simple POS System");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(850, 500);
        setLocationRelativeTo(null);

        mainPanel = new JPanel(new CardLayout());
        add(mainPanel);

        // Start Panel
        StartPanel startPanel = new StartPanel(this::showPOSSystem);
        mainPanel.add(startPanel, "start");

        // POS Panel
        JPanel posPanel = createPOSPanel();
        mainPanel.add(posPanel, "pos");

        showStartPanel();
        setVisible(true);
    }

    private void showStartPanel() {
        ((CardLayout) mainPanel.getLayout()).show(mainPanel, "start");
    }

    private void showPOSSystem() {
        ((CardLayout) mainPanel.getLayout()).show(mainPanel, "pos");
        display.showMessage("Welcome! Please select an item...");
    }

    private JPanel createPOSPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));

        display = new RegisterDisplay();
        panel.add(display, BorderLayout.NORTH);

        //Create products
        List<Product> products = List.of(
                new DrinkItem("Hazelnut", 80.00),
                new DrinkItem("Americano", 90.00),
                new DrinkItem("Cappuccino", 120.00),
                new DrinkItem("Matcha", 130.00),
                new DrinkItem("Mocha", 140.00),
                new DrinkItem("Macchiato", 110.00),
                new FoodItem("Chicken Sandwich", 130.00),
                new FoodItem("Pancakes", 100.00),
                new FoodItem("Waffles", 120.00),
                new FoodItem("Fries", 70.00),
                new FoodItem("Pasta", 180.00)
        );

        //Create panels
        cartPanel = new CartPanel();
        ProductPanel productPanel = new ProductPanel(products, cart, () -> {
            cartPanel.updateCart(cart);
            display.showMessage("Item added! Total: ₱" + String.format("%.2f", cart.getTotal()));
        });

        //Control buttons
        JPanel controlPanel = new JPanel();
        JButton checkoutBtn = new JButton("Checkout");
        JButton clearBtn = new JButton("Clear Cart");

        checkoutBtn.addActionListener(e -> {
            display.showMessage("Processing checkout...");
            showCheckoutDialog();
        });

        clearBtn.addActionListener(e -> {
            cart.clear();
            cartPanel.updateCart(cart);
            display.showMessage("Cart cleared!");
        });

        controlPanel.add(clearBtn);
        controlPanel.add(checkoutBtn);

        //Layout
        panel.add(productPanel, BorderLayout.CENTER);
        panel.add(cartPanel, BorderLayout.EAST);
        panel.add(controlPanel, BorderLayout.SOUTH);

        return panel;
    }

    private void showCheckoutDialog() {
        JOptionPane.showMessageDialog(this,
                String.format("Total to pay: ₱%.2f", cart.getTotal()),
                "Checkout", JOptionPane.INFORMATION_MESSAGE);

        display.showMessage("Payment received. Thank you!");
        cart.clear();
        cartPanel.updateCart(cart);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MainPOSFrame::new);
    }
}