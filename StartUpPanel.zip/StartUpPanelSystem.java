import javax.swing.*;
import java.awt.*;

//StartUp Panel
class StartUpPanel extends JPanel {
    public StartUpPanel() {
        setLayout(new BorderLayout());
        setBackground(new Color(20, 20, 20));

        JLabel title = new JLabel("Welcome to Coffee Shop (Name)", SwingConstants.CENTER);
        title.setFont(new Font("Consolas", Font.BOLD, 26));
        title.setForeground(Color.GREEN);

        JLabel msg = new JLabel("Would you like to start ordering?", SwingConstants.CENTER);
        msg.setFont(new Font("Arial", Font.PLAIN, 22));
        msg.setForeground(Color.WHITE);

        JButton startBtn = new JButton("Start Order");
        JButton exitBtn = new JButton("Exit");

        //Button for start
        startBtn.setFont(new Font("Arial", Font.BOLD, 18));
        startBtn.setBackground(new Color(46, 139, 87)); // green
        startBtn.setForeground(Color.WHITE);
        startBtn.setFocusPainted(false);
        startBtn.setPreferredSize(new Dimension(150, 45));

        //Button for exit
        exitBtn.setFont(new Font("Arial", Font.BOLD, 18));
        exitBtn.setBackground(new Color(178, 34, 34)); // red
        exitBtn.setForeground(Color.WHITE);
        exitBtn.setFocusPainted(false);
        exitBtn.setPreferredSize(new Dimension(150, 45));

        startBtn.addActionListener(e -> {
        });
        exitBtn.addActionListener(e -> System.exit(0));

        //Buttons
        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(new Color(20, 20, 20));
        bottomPanel.add(startBtn);
        bottomPanel.add(Box.createHorizontalStrut(15)); // spacing
        bottomPanel.add(exitBtn);

        add(title, BorderLayout.NORTH);
        add(msg, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);
    }
}

public class StartUpPanelSystem {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Coffee Shop");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(850, 500);
            frame.setLocationRelativeTo(null);

            StartUpPanel startPanel = new StartUpPanel();
            frame.add(startPanel);

            frame.setVisible(true);
        });
    }
}